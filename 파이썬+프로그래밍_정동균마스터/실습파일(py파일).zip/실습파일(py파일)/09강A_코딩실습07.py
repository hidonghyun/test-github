학년 = int(input('몇 학년인가요(1~6)?'))

if 학년 >=2 and 학년 <=4:
    print('햄버거를 드세요.')
else:
    print('김밥을 드세요.')
    