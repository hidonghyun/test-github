등수 = input('몇 등인가요(1 또는 2)?')

if 등수 == '1' :
    print('TV를 보며 편하게 쉬세요.')
else:
    print('설거지 당첨!')